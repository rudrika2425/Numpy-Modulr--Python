'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
a = np.arange(9, dtype = 'float').reshape(3,3)
print ('First array:' )
print (a)

print ('Second array:' )
b = np.array([10,10,10])
print (b)

print( 'Add the two arrays:' )
print (np.add(a,b) )