
import numpy as np
a = np.array([1,2,3])
print(a)
