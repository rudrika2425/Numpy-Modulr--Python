
import numpy as np 
a=np.array([1,2,3])
b=np.array([5,6,7])
print(np.multiply(a,b))
print(np.divide(a,b))
print(np.dot(a,b))
print(np.max(a))
print(np.min(a))
print(np.var(a))
print(np.mean(a))
print(np.sum(a))
print(np.std(a))